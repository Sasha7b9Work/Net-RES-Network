import os
import sys
import subprocess


def compile_to_exe(script_name):
    # Определяем путь к PyInstaller
    pyinstaller_path = os.path.join(sys.prefix, 'Scripts', 'pyinstaller.exe')

    if not os.path.exists(pyinstaller_path):
        # Если не найден в стандартном месте, попробуем альтернативный путь
        pyinstaller_path = os.path.join(sys.prefix, 'Scripts', 'pyinstaller')

    if not os.path.exists(pyinstaller_path):
        print("Ошибка: PyInstaller не найден. Убедитесь, что он установлен.")
        return

    # Определяем путь к скрипту
    script_path = os.path.abspath(script_name)

    if not os.path.exists(script_path):
        print(f"Ошибка: Скрипт '{script_name}' не найден.")
        return

    # Команды для сборки
    build_command = [
        pyinstaller_path,
        '--onefile',
        '--windowed',
        script_path
    ]

    # Выполнение команды сборки
    try:
        subprocess.check_call(build_command)
        print(f"\nУспешно скомпилировано в исполняемый файл: {os.path.splitext(script_name)[0]}.exe\n")
    except subprocess.CalledProcessError as e:
        print(f"\nОшибка при компиляции: {e}\n")


if __name__ == "__main__":
    compile_to_exe('main.py')
