from App import root
from App.View import MainView


if __name__ == "__main__":
    view = MainView()

    view.pack(fill="both", expand=True)
    root.mainloop()
