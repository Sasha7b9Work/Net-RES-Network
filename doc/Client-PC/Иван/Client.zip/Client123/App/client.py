import asyncio
import aiohttp
import tkinter as tk
from tkinter import ttk
from datetime import datetime

BASE_URL = "http://127.0.0.1:8000/weather"

async def fetch_latest_weather(sensor_id):
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{BASE_URL}/{sensor_id}") as response:
            if response.status == 200:
                return await response.json()
            return None

async def fetch_weather_history(sensor_id):
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{BASE_URL}/{sensor_id}/history") as response:
            if response.status == 200:
                return await response.json()
            return None

def display_latest_weather():
    sensor_id = int(sensor_id_entry.get())
    loop = asyncio.get_event_loop()
    weather = loop.run_until_complete(fetch_latest_weather(sensor_id))
    if weather:
        weather_info.set(f"Temperature: {weather['temperature']} °C\n"
                         f"Humidity: {weather['humidity']} %\n"
                         f"Pressure: {weather['pressure']} hPa\n"
                         f"Windspeed: {weather['windspeed']} m/s\n"
                         f"Timestamp: {datetime.fromisoformat(weather['timestamp'])}")
    else:
        weather_info.set("No data available")

def display_weather_history():
    sensor_id = int(sensor_id_entry.get())
    loop = asyncio.get_event_loop()
    history = loop.run_until_complete(fetch_weather_history(sensor_id))
    if history:
        history_str = ""
        for record in history:
            history_str += (f"ID: {record['id']}, "
                            f"Temp: {record['temperature']} °C, "
                            f"Humidity: {record['humidity']} %, "
                            f"Pressure: {record['pressure']} hPa, "
                            f"Windspeed: {record['windspeed']} m/s, "
                            f"Time: {datetime.fromisoformat(record['timestamp'])}\n")
        history_info.set(history_str)
    else:
        history_info.set("No history data available")

def finish():
    app.destroy()

app = tk.Tk()
app.title("Метео Курач")
# app.attributes("-fullscreen", True)
app.protocol("WM_DELETE_WINDOW", finish)
# app.attributes("-toolwindow", True)

#добавить иконку


sensor_id_label = tk.Label(app, text="Sensor ID:")
sensor_id_label.pack()

sensor_id_entry = tk.Entry(app)
sensor_id_entry.pack()

latest_weather_button = tk.Button(app, text="Get Latest Weather", command=display_latest_weather)
latest_weather_button.pack()

weather_info = tk.StringVar()
weather_label = tk.Label(app, textvariable=weather_info, justify=tk.LEFT)
weather_label.pack()

# history_weather_button = tk.Button(app, text="Get Weather History", command=display_weather_history)
# history_weather_button.pack()

history_info = tk.StringVar()
history_label = tk.Label(app, textvariable=history_info, justify=tk.LEFT)
history_label.pack()

app.mainloop()
