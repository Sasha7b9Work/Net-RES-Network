import tkinter as tk
from dotenv import load_dotenv
import os


load_dotenv()
base_url = os.getenv('BASE_URL')
if not base_url:
    base_url = "http://127.0.0.1:8000"
root = tk.Tk()
root.title("Метео")
