import asyncio
import aiohttp
from App import base_url


async def fetch_latest_weather(sensor_id):
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{base_url}/weather/{sensor_id}") as response:
            if response.status == 200:
                return await response.json()
            return None


async def fetch_weather_history(sensor_id):
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{base_url}/weather/{sensor_id}/history") as response:
            if response.status == 200:
                return await response.json()
            return None


async def fetch_sensors_id():
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{base_url}/sensors") as response:
            if response.status == 200:
                return await response.json()
            return None