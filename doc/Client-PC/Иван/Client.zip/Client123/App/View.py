from tkinter import ttk, Frame, messagebox
from tkinter import Y, LEFT, BOTTOM, S

import aiohttp.client_exceptions
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import asyncio
from datetime import datetime

from App.Controller import fetch_sensors_id, fetch_latest_weather, fetch_weather_history


def create_plot():
    """
    Создание графика с заданными параметрами.

    Параметры:
    x (list): Данные по оси X
    y (list): Данные по оси Y
    title (str): Заголовок графика
    xlabel (str): Метка оси X
    ylabel (str): Метка оси Y
    legend_label (str): Метка для легенды
    color (str): Цвет линии графика
    marker (str): Маркер точек на графике
    figsize (tuple): Размер фигуры
    dpi (int): Разрешение фигуры
    """
    title = 'График'
    xlabel = "x"
    ylabel = "Время"
    figsize = (10, 7)
    dpi = 70
    # Создание фигуры
    fig = Figure(figsize=figsize, dpi=dpi)

    # Создание субплота
    ax = fig.add_subplot(1, 1, 1)

    # Добавление меток осей
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)

    # Добавление заголовка
    ax.set_title(title)

    return fig


class MainView(Frame):
    def __init__(self):
        super().__init__()
        self.sensor_list = []
        self.history = {}
        self.current_graph_mode = 'temperature'
        self.current_sensor = 'Выберите датчик'
        self.left_frame = Frame(self, borderwidth=1, relief='solid')
        self.central_frame = ttk.Frame(self, borderwidth=1, relief='solid')
        self.right_frame = ttk.Frame(self, borderwidth=1, relief='solid')

        self.data_sensor = (
            f"Температура:  °C, \n"
            f"Влажность:  %, \n"
            f"Давление:  кПа, \n"
            f"Скорость ветра:  м/с, \n"
            f"Время: \n")
        self.map_legend_dict = {'temperature': ['Температура', '°C'],
                                'humidity': ['Влажность', '%'],
                                'pressure': ['Давление', 'кПа'],
                                'windspeed': ['Скорость ветра', 'м/с']}
        self.main_label = ttk.Label(self.left_frame, text="Meteo", font=28)

        # self.sensors_label = ttk.Label(self.left_frame, text=data_sensor)

        self.button_update_sensor_list = ttk.Button(self.left_frame, text="Обновить", width=28,
                                                    command=self.run_update_sensors)

        self.sensor_id_label = ttk.Label(self.central_frame, text="Идентификатор", font=28)
        self.sensor_id_label_content = ttk.Label(self.central_frame, text="")
        self.sensor_data_label = ttk.Label(self.central_frame, text="Данные", font=28)
        self.sensor_data = ttk.Label(self.central_frame, text=self.data_sensor)

        self.parameters_list = ['Температура', 'Влажность', "Давление", "Скорость ветра", "Время"]
        self.mode_list = ['temperature', 'humidity', 'pressure', 'windspeed']
        self.graph_buttons_frame = ttk.Frame(self.central_frame, borderwidth=1, relief='solid')

        self.graph = FigureCanvasTkAgg(create_plot(), master=self.graph_buttons_frame)
        self.graph.draw()

        self.button_update_current_weather = ttk.Button(self.central_frame, text="Обновить", width=28,
                                                        command=self.update_current_weather)

        self.history_label = ttk.Label(self.right_frame, text="История")
        self.tree = ttk.Treeview(columns=self.parameters_list, show="headings", master=self.right_frame)
        for column in self.parameters_list:
            self.tree.column(column, width=100)
            self.tree.heading(column, text=column)
        self.pack_widgets()

    def pack_widgets(self):
        self.left_frame.pack(side=LEFT, fill=Y)
        self.central_frame.pack(side=LEFT, fill=Y, expand=1)
        self.right_frame.pack(side=LEFT, fill=Y)

        self.main_label.pack()
        asyncio.run(self.pack_sensors())
        self.button_update_sensor_list.pack(expand=1, anchor=S, pady=20, padx=5, ipady=5)

        self.sensor_id_label.pack()
        self.sensor_id_label_content.pack()
        self.sensor_data_label.pack()
        self.sensor_data.pack()

        self.graph_buttons_frame.pack()
        self.button_list = []
        self.graph.get_tk_widget().pack(side=BOTTOM, expand=1)
        for name in range(len(self.mode_list)):
            self.button_list.append(ttk.Button(self.graph_buttons_frame, text=self.parameters_list[name],
                                               command=lambda x=self.mode_list[name]: self.set_graph_mode(x))
                                    .pack(side=LEFT))

        self.button_update_current_weather.pack()

        self.history_label.pack()
        self.tree.pack()

    async def pack_sensors(self):
        try:
            sensors = await fetch_sensors_id()
        except aiohttp.client_exceptions.ClientConnectionError as e:
            messagebox.showerror("Error", f'{e}')
            return
        for sensor in sensors:
            button = ttk.Button(self.left_frame, text=sensor['description'], command=lambda x=sensor:
            self.set_current_sensor(x))
            self.sensor_list.append(button)
            button.pack()

    def run_update_sensors(self):
        asyncio.run(self.update_sensors())
        self.button_update_sensor_list.destroy()
        self.button_update_sensor_list = ttk.Button(self.left_frame, text="Обновить", width=28,
                                                    command=self.run_update_sensors)
        self.button_update_sensor_list.pack(expand=1, anchor=S, pady=20, padx=5, ipady=5)

    async def update_sensors(self):
        try:
            sensors = await fetch_sensors_id()
        except aiohttp.client_exceptions.ClientConnectionError as e:
            messagebox.showerror("Error", f'{e}')
            return

        for button in self.sensor_list:
            button.destroy()
        for sensor in sensors:
            button = ttk.Button(self.left_frame, text=sensor['description'], command=lambda x=sensor:
            self.set_current_sensor(x))
            self.sensor_list.append(button)
            button.pack()

    def set_current_sensor(self, new_sensor):
        self.current_sensor = new_sensor['id']
        self.sensor_id_label_content.config(text=new_sensor['description'])
        asyncio.run(self.set_current_weather())
        asyncio.run(self.set_weather_history())
        self.update_graph()

    async def set_current_weather(self):
        try:
            weather = await fetch_latest_weather(self.current_sensor)
        except aiohttp.client_exceptions.ClientConnectionError as e:
            messagebox.showerror("Error", f'{e}')
            return
        weather['timestamp'] = datetime.strptime(weather['timestamp'], "%Y-%m-%dT%H:%M:%S.%f")
        self.data_sensor = (
            f"Температура: {round(weather['temperature'], 2)} °C, \n"
            f"Влажность: {round(weather['humidity'], 2)} %, \n"
            f"Давление: {round(weather['pressure'], 2)} кПа, \n"
            f"Скорость ветра: {round(weather['windspeed'], 2)} м/с, \n"
            f"Время: {weather['timestamp'].strftime('%H:%M %d.%m.%Y')} \n")
        self.sensor_data.config(text=self.data_sensor)

    def update_current_weather(self):
        asyncio.run(self.set_current_weather())
        asyncio.run(self.set_weather_history())
        self.update_graph()

    async def set_weather_history(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        try:
            self.history = await fetch_weather_history(self.current_sensor)
        except aiohttp.client_exceptions.ClientConnectionError as e:
            messagebox.showerror("Error", f'{e}')
            return
        for weather_record in self.history:
            weather_record['timestamp'] = datetime.strptime(weather_record['timestamp'],
                                                            "%Y-%m-%dT%H:%M:%S.%f").strftime('%H:%M %d.%m.%Y')
            new_values = [weather_record[key] for key in weather_record.keys()]
            new_values = [round(x, 2) if isinstance(x, (int, float)) else x for x in new_values]
            self.tree.insert('', 'end', values=new_values)
            self.tree.update()

    def set_graph_mode(self, mode):
        self.current_graph_mode = mode
        self.update_graph()

    def update_graph(self):
        fig = self.graph.figure

        fig.clf()

        ax = fig.add_subplot(1, 1, 1)

        ax.set_ylabel(self.map_legend_dict[self.current_graph_mode][1])
        ax.set_title(self.map_legend_dict[self.current_graph_mode][0])

        new_data_y = [weather[self.current_graph_mode] for weather in self.history]

        new_data_x = [weather['timestamp'] for weather in self.history]

        # ax.set_title()

        ax.plot(new_data_x, new_data_y)

        self.graph.draw()
