from pydantic import BaseModel
from typing import Union
from datetime import datetime


class Weather(BaseModel):

    temperature: float
    humidity: float
    pressure: float
    windspeed: float
    timestamp: Union[datetime, None] = None
    sensor_id: int
