from sqlalchemy import create_engine, Column, Integer, Float, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime, timezone
import random
import os
from dotenv import load_dotenv


Base = declarative_base()


class WeatherDto(Base):
    __tablename__ = "weather"

    id = Column(Integer, primary_key=True, index=True)
    temperature = Column(Float)
    humidity = Column(Float)
    pressure = Column(Float)
    windspeed = Column(Float)
    timestamp = Column(DateTime, default=datetime.now(timezone.utc))
    sensor_id = Column(Integer)

# Подключение к базе данных
load_dotenv()
SQLALCHEMY_DATABASE_URL = os.getenv('SQLALCHEMY_DATABASE_URL')
engine = create_engine(SQLALCHEMY_DATABASE_URL)

# Создание таблицы
Base.metadata.create_all(bind=engine)

# Создание сессии для взаимодействия с базой данных
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
session = SessionLocal()

# Заполнение таблицы случайными данными
temperature = random.uniform(-20, 40)  # случайная температура в диапазоне от -20 до 40 градусов Цельсия
humidity = random.uniform(0, 100)  # случайная влажность в диапазоне от 0 до 100%
pressure = random.uniform(950, 1050)  # случайное давление в диапазоне от 950 до 1050 гПа
windspeed = random.uniform(0, 30)  # случайная скорость ветра в диапазоне от 0 до 30 м/с
sensor_id = random.randint(1, 5)  # случайный идентификатор датчика в диапазоне от 1 до 5
weather_data = WeatherDto(temperature=temperature, humidity=humidity, pressure=pressure, windspeed=windspeed, sensor_id=sensor_id)
session.add(weather_data)

# Сохранение изменений в базе данных
session.commit()

# Закрытие сессии
session.close()
