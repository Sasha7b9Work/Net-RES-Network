import asyncio
import json


class TCPServer:
    def __init__(self, host: str, port: int, sensors: list):
        self.host = host
        self.port = port
        self.sensors = sensors

    async def handle_client(self, reader, writer):
        try:
            while True:
                data = await reader.read(100)
                if not data:
                    break
                # в decode можно настроить кодировку, типа utf-8 и тд
                message = data.decode()
                info = json.loads(message)
                if info['id'] not in self.sensors:
                    self.sensors.append(info['id'])
                    print(self.sensors)
                # Тут будет логика добавления данных в бд, в тестовом варианте тяжко переделать
                print(f'''
                Температура: {info['Temperature']}
                Время: {info['time']}
                Идентификатор датчика: {info['id']}
                Хост/Порт: {writer.get_extra_info('peername')}
                ''')

        except Exception as e:
            print(f"Ошибка: {e}")
        finally:
            print("Closing connection")
            writer.close()
            await writer.wait_closed()

    async def start_server(self):
        server = await asyncio.start_server(
            self.handle_client, self.host, self.port
        )

        addr = server.sockets[0].getsockname()
        print(f"Serving on {addr}")

        async with server:
            await server.serve_forever()

