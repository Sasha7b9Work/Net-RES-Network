from pydantic import BaseModel


class WeatherRequest(BaseModel):
    temperature: float
    humidity: float
    pressure: float
    windspeed: float
    timestamp: str
    sensor_id: int
