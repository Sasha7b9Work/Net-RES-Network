from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import Session, sessionmaker
from datetime import datetime, timezone
from sqlalchemy import Column, Integer, Float, DateTime
from sqlalchemy import desc
from dotenv import load_dotenv
import os


base = declarative_base()


class WeatherDto(base):
    __tablename__ = "weather"

    id = Column(Integer, primary_key=True, index=True)
    temperature = Column(Float)
    humidity = Column(Float)
    pressure = Column(Float)
    windspeed = Column(Float)
    timestamp = Column(DateTime, default=datetime.now(timezone.utc))
    sensor_id = Column(Integer)


class WeatherService:
    def __init__(self):
        load_dotenv()
        self.engine = create_engine(os.getenv('SQLALCHEMY_DATABASE_URL'))
        self.engine.connect()
        self.base = base

    def get_base(self):
        return self.base

    def add_weather(self, weather: dict):
        data = WeatherDto(
            temperature=weather['temperature'],
            humidity=weather['humidity'],
            pressure=weather['pressure'],
            windspeed=weather['windspeed'],
            sensor_id=weather['sensor_id'],
        )

        with Session(self.engine) as session:
            session.add(data)
            session.commit()

    def get_weather(self, sensor_id: str):
        with Session(self.engine) as session:
            try:
                result = session.query(WeatherDto).filter(
                    WeatherDto.sensor_id == sensor_id
                ).order_by(desc(WeatherDto.timestamp)).first()
                return result
            except Exception as e:
                return None


    def get_weather_history(self, sensor_id: str):
        with Session(self.engine) as session:
            try:
                result = session.query(WeatherDto).filter(
                    WeatherDto.sensor_id == sensor_id
                ).limit(100)
                return result
            except Exception as e:
                return None
