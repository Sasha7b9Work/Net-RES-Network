# from app.routes import weather_service
from sqlalchemy import Column, Integer, Float, DateTime
from datetime import datetime, timezone
from app.weather_service import base


class WeatherDto(base):
    __tablename__ = "weather"

    id = Column(Integer, primary_key=True, index=True)
    temperature = Column(Float)
    humidity = Column(Float)
    pressure = Column(Float)
    windspeed = Column(Float)
    timestamp = Column(DateTime, default=datetime.now(timezone.utc))
    sensor_id = Column(Integer)
