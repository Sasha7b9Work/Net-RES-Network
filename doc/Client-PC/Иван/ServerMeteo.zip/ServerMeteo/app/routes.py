from fastapi import APIRouter, HTTPException, status
import asyncio
import os
from dotenv import load_dotenv
from app.weather_service import WeatherService
from app.weather_responce_dto import Weather
from app.sensor_dto import Sensor
from app.weather_request_dto import WeatherRequest
from app.tcp_server import TCPServer


router = APIRouter()

weather_service = WeatherService()

sensors_list = []

load_dotenv()
try:
    tcp_server = TCPServer(os.getenv('TCP_RUN_HOST'), int(os.getenv('TCP_RUN_PORT')), sensors_list)
except TypeError:
    print('Run tcp-server with default config')
    tcp_server = TCPServer('0.0.0.0', 3333, sensors_list)


@router.on_event("startup")
async def startup_event():
    asyncio.create_task(tcp_server.start_server())


@router.get("/weather/{sensor_id}")
async def get_weather_from_sensor(sensor_id) -> Weather:
    # print(weather_service.get_weather(sensor_id))
    weather = weather_service.get_weather(sensor_id)
    if weather:
        return weather
    else:
        raise HTTPException(status_code=404, detail="Item not found")


@router.get("/sensors")
async def get_sensors() -> list[Sensor]:
    return [Sensor(id=int(sensor_id, 16), description='Description') for sensor_id in sensors_list]


@router.post("/weather")
async def post_weather_from_sensor(weather: WeatherRequest):
    weather_service.add_weather(dict(weather))
    return {'message': 'ok'}


@router.get("/weather/{sensor_id}/history")
async def get_weather_history(sensor_id) -> list[Weather]:
    weather = weather_service.get_weather_history(sensor_id)
    if weather:
        return weather
    else:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Weather data not found")
