import uvicorn
from dotenv import load_dotenv
import os

if __name__ == "__main__":
    load_dotenv()
    try:
        uvicorn.run("app:app", host=os.getenv('HTTP_RUN_HOST'),
                    port=int(os.getenv('HTTP_RUN_PORT')))
    except TypeError:
        print('Run server with default config')
        uvicorn.run("app:app")
